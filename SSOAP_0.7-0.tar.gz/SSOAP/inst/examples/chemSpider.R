library(SSOAP)
cs = processWSDL("http://www.chemspider.com/MassSpecAPI.asmx?WSDL")
o = genSOAPClientInterface(, cs)
o@functions$SearchByMass2(list(mass = 89.04767, range = 0.01)) 
o@functions$SearchByMass2(mass = 89.04767, range = 0.01) # also works 
o@functions$GetExtendedCompoundInfo(list(CSID=23078572L, token = "717cf9b9-9721-4e8b-825a-b6a65e106c1e"))
o@functions$GetExtendedCompoundInfo(CSID=23078572L, token = "717cf9b9-9721-4e8b-825a-b6a65e106c1e") # works too.

