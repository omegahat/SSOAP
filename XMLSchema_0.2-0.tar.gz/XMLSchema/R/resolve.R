resolveError =
  #
  # A function to raise a special error for resolving types within the WSDL schema.
  #
function(..., class = "SOAPResolveError")
{
   x = simpleError(paste(..., sep = ""))
   class(x) = c(class, class(x))
   stop(x)
}


# Resolve finds the definition and its contents within a context
# It can resolve at one level or all the way down.
# The definitions here are typically SOAP types.

setGeneric("resolve", function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
                       standardGeneric("resolve")
                     })


setMethod("resolve", c("RestrictedStringPatternDefinition", "SchemaCollection"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
              obj
           })

setMethod("resolve", c("NULL", "list"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
             NULL
           })

setMethod("resolve", c("BasicSOAPType", "list"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
             stop("No method for this type ", class(obj))
           })

if(FALSE) {
setMethod("resolve", c("SOAPTypeReference", "list"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
             
             resolve(obj@name, context, namespaces, recursive, raiseError)
           })

setMethod("resolve", c("SOAPTypeReference", "SchemaCollection"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
             resolve(obj@name, context, namespaces, recursive, raiseError)
           })
}

setMethod("resolve", c("SOAPTypeReference", "SchemaCollection"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
             if(length(context) == 0) 
               return(obj)

               ans = resolve(obj@name, context, namespaces, recursive, FALSE)
               if(is.null(ans) &&  substring(obj@name, 1, 7) == "ArrayOf") {
                  elementType = substring(obj@name, 8)

                  ans = new("SimpleSequenceType",
                               name = obj@name,
                               elementType = elementType,
                               elType = resolve(elementType, context, namespaces, recursive))
                }

                ans
           })

setMethod("resolve", c("AttributeDef", "list"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
             obj #XXX
           })


setMethod("resolve", c("ClassDefinition", "list"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
             obj@slotTypes = lapply(obj@slotTypes, resolve, context, namespaces, recursive)
             obj
           })

setMethod("resolve", c("WSDLTypeDescription", "list"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
             resolve(obj$definition, context, namespaces, recursive, raiseError)
           })


setMethod("resolve", c("PrimitiveSOAPType", "list"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
             obj
           })

setMethod("resolve", c("RestrictedStringDefinition", "list"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
             obj
           })

setMethod("resolve", c("SOAPVoidType"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
             obj
           })


setMethod("resolve", c("ArrayType", "list"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
             if(recursive && (is.null(obj@elType) || length(obj@elType@name) == 0)) {
               name = obj@elementType
               obj@elType = resolve(name, context, namespaces, recursive, raiseError)
             }
             obj
           })

setMethod("resolve", c("SOAPVoidType", "SchemaCollection"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) 
	       return(obj))

setMethod("resolve", c("SOAPVoidType"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) 
	       return(obj))



setMethod("resolve", c("character", "SchemaCollection"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
#cat("resolve(, SchemaCollection)", obj, "\n")             
             els = strsplit(obj, ":")[[1]]
             if(length(els) > 1)
               obj = els[2]

             w = sapply(context,
                        function(ctxt) {
                          if(inherits(ctxt, "SchemaTypes") || inherits(ctxt, "SchemaCollection"))
                              resolve(obj, ctxt, namespaces, recursive = FALSE, raiseError = FALSE)
                          else if(obj %in% names(ctxt))
                               ctxt[[obj]]
                          else
                            NULL
                        })

             i = sapply(w, is.null)
             
             if(all(i)) {
	        if(raiseError)
           	    resolveError("Cannot resolve ", obj, " in ", class(context))
                 else
    	           return(NULL)
             } else if(sum(!i) > 1)
                 warning("resolved ", obj, "in ", sum(!i), " schema/elements")

	     val = w[!i][[1]]   # # ((context[w])[[1]])[[obj]]

             if(recursive) {
              #   cat("Calling resolve recursively for", obj, "with class", class(val), "\n")
    	         resolve(val, context, namespaces, recursive, raiseError)
              }
             else
                 val
           })


asQName = function(x) strsplit(x, ":")[[1]]

setMethod("resolve", c("SimpleSequenceType", "SchemaCollection"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
              obj
            })



setMethod("resolve", c("SOAPType", "SchemaCollection"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
               #XXX deal with the namespace.
               #!!! This will cause infinite recursion if there is no method for the specific type.
              resolve(obj@name, context, namespaces, recursive, raiseError)
            })

setMethod("resolve", c("SOAPType", "list"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
               #XXX deal with the namespace. 
              resolve(obj@name, context, namespaces, recursive, raiseError)
            })

setMethod("resolve", c("EnumValuesDef", "list"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
             obj
            })

setMethod("resolve", c("RestrictedSetInteger", "list"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
             obj
            })


setMethod("resolve", c("character", "list"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {

#cat("resolve(, list)", obj, "\n")

              if(length(context) == 0) {
                if(raiseError)
                    resolveError("Cannot resolve SOAP type in empty context")
                else
                   return(NULL)
              }
              
                  # remove the [] literals and split the string into
                  # namespace prefix & label.
               els = strsplit(gsub("\\[\\]", "", obj), ":")[[1]]
               if(length(els) == 2) { # array
                 if(els[1] == "xsd") {   #XXX need to match the namespace URI!
                   return(SOAPType(els[2], els[1]))
                 }
                  # Work with just the label, ignoring the namespace prefix.
                 els = els[2]
               } 

                    # deal with the namespace in the schema names.
               el = match(els[1], names(context))
               if(is.na(el)) 
                  el = match(els[1], gsub(".*:", "", names(context)))

            
            
               if(is.na(el))  {

                 is.schema = sapply(context, is, "SchemaTypes")
                 if(any(is.schema)) {
                    tmp = lapply(context[is.schema], function(x) resolve(obj, x, recursive, raiseError = FALSE))
                    i = sapply(tmp, is.null)
                    if(!all(i))
                      return(tmp[!i][[1]])
                 }

                 if(raiseError)
                     resolveError("Cannot resolve SOAPTypeReference ", els[1], " in list")
                 else
                     return(NULL)
               }

               tmp = context[[el]]
               if(is(tmp, "XMLNode") && xmlName(tmp) == "element") {
                  id = asQName(xmlGetAttr(tmp, "type"))[2]
                  i = match(id, names(context))
                  if(is.na(i)) {
                    stop("unexpected problems when dealing with an <element> node that has no corresponding type in the larger context", class = "UnresolvedElementRef")
                    return(NULL)
                  }
                  el = i
               }

               if("definition" %in% names(context[[el]]))
                  ans = context[[el]]$definition
               else
                  ans = context[[el]]

               if(is.null(ans)) { #XXX why will the object above not have a definition.
                if(raiseError)
                   resolveError("NULL value for resolved type")
                else
                   return(NULL)
               }
              
               if(recursive && (is(ans, "ClassDefinition") || !is(ans, "TerminalSOAPType"))) {
#                  cat("Calling resolve recursively for", obj, "with", class(ans), "\n")
                  ans = resolve(ans, context, namespaces, recursive, raiseError)
                }

               ans
           })


setMethod("resolve", c("SimpleElement", "list"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
             resolve(obj@type, context, namespaces, recursive, raiseError)
           })


setMethod("resolve", c("Element", "list"),
           function(obj, context, namespaces = character(), recursive = TRUE, raiseError = TRUE) {
                   # could give infinite recursion. See msnSearch.wsdl and SearchResponse.
                   # So just look it up.
             if(!is(obj@type, "SOAPTypeReference"))
                return(obj@type)
             
             lookupType(obj@type@name, context)
           })

