XMLbase64Decode =
function(x) {
  library(RCurl)
  base64Decode(xmlValue(x))
}

# Named list of mappings from primitive SOAP types
# to S data types.
# From http://www.w3.org/TR/xmlschema-2/#built-in-primitive-datatypes
# d means done
# w means "needs more work"
##  d    3.2.1 string
##  d    3.2.2 boolean
##  d    3.2.3 decimal
##  d    3.2.4 float         
##  d    3.2.5 double
##       3.2.6 duration
##  d    3.2.7 dateTime
##  d    3.2.8 time
##  d    3.2.9 date
##       3.2.10 gYearMonth
##       3.2.11 gYear
##       3.2.12 gMonthDay
##       3.2.13 gDay
##       3.2.14 gMonth
##  w    3.2.15 hexBinary
##  w    3.2.16 base64Binary
##       3.2.17 anyURI
##       3.2.18 QName
##       3.2.19 NOTATION

# Is there an int? Yes, it is restricted from other types.
# See the tree at the top of section 3.2 of the document above.

XMLSchemaTypes <-
  list("character" = list("xsi:type" = "xsd:string", type = "string"),
       "normalizedCharacter" = list("xsi:type" = "xsd:string", type = "normalizedString"),
       
       "numeric"   = list("xsi:type" = "xsd:float", type = "float"),
       "numeric"   = list("xsi:type" = "xsd:long", type = "long"),
       "numeric"   = list("xsi:type" = "xsd:decimal", type = "decimal"),
#?      "double"   = list("xsi:type" = "xsd:float", type = "float"),
       "numeric"   = list("xsi:type" = "xsd:double", type = "double"),       
       "integer"   = list("xsi:type" = "xsd:int", type = "int"),
       "integer"   = list("xsi:type" = "xsd:unsignedShort", type = "unsignedShort"),       
       "positiveInteger" = list("xsi:type" = "xsd:int", type = "positiveInteger",
                                  from = function(x) { if(x <= 0) stop("must be positive") ; as.integer(x)}),
       "nonNegativeInteger" = list("xsi:type" = "xsd:int", type = "nonNegativeInteger",
                                  from = function(x) { if(x < 0) stop("must be non-negative") ; as.integer(x)}),              
# xsd:integer allows for a wider range than R's integer.
       "numeric"   = list("xsi:type" = "xsd:integer", type = "integer"),
       "logical"   = list("xsi:type" = "xsd:boolean", type = "boolean"),

#TMP       "POSIXct"   = list("xsi:type" = "xsd:date", type = "date"),
       # Use SOAPDate for the as.SOAPDate to be able to allow both strings and POSIXt types.
       "SOAPDate"   = list("xsi:type" = "xsd:date", type = "date", soapClass = "SOAPDate"),       
       "SOAPDateTime"   = list("xsi:type" = "xsd:dateTime", type = "dateTime", soapClass = "SOAPDateTime"),
       "SOAPTime"   = list("xsi:type" = "xsd:time", type = "time", soapClass = "SOAPTime"),

       gYear = list('xsi:type' = 'xsd:gYear', type = "gYear"),

       "duration" = list("xsi:type" = "xsd:duration", type = "duration"),

       "raw"       = list("xsi:type" = "xsd:base64Binary", type = "base64Binary", from = XMLbase64Decode),
       "raw"       = list("xsi:type" = "xsd:hexBinary", type = "hexBinary"),

       "URI"       = list("xsi:type" = "xsd:anyURI", type = "anyURI", from = parseURI),
       "token"       = list("xsi:type" = "xsd:token", type = "token"),

       "ANY"   = list("xsi:type" = "xsd:anyType", type = "anyType"),
#QName
#NOTATION
       "NULL"      = list("xsi:null" = 1, "xsi:type" = "null", type = "null"),

       "NMTOKEN" = list("xsi:NMTOKEN" = "NMTOKEN", type = "NMTOKEN")
    )




setClass("NMTOKEN", contains = "character",
          validity =
             function(object) {
                length(grep("[[:space:]]", object)) == 0
             })

trim =
function(x)
  gsub("^[[:space:]]*(.*)[[:space:]]*$", "\\1", x)


setAs("character", "NMTOKEN",
      function(from) {
         new("NMTOKEN", trim(from))
      })

setClass("positiveInteger", contains = "integer",
           validity = function(object) {
                if(object <= 0)
                   "value must be positive"
                else
                  TRUE
             })

setClass("nonNegativeInteger", contains = "integer",
           validity = function(object) {
                if(object < 0)
                   "value must be non-negative"
                else
                  TRUE
             })

setClass("normalizedCharacter",
           contains = "character",
          validity = function(object) {
            num = length(grep("[\\\n\\\t\\\r]", object))
            if(num == 0)
              TRUE
            else
               "string contains one or more newlines, tabs or line feeds"
          })

setAs("character", "normalizedCharacter",
      function(from) {
       new("normalizedCharacter", gsub("[\\\n\\\t\\\r]", " ", from))
      })

# as(c("abc\tdef", "abc\ndef"), "normalizedCharacter")

setAs("numeric", "positiveInteger", 
function(from)
{
   from = as.integer(from)  
   if(from <= 0)
     stop("value must be positive")

   from
})

setAs("numeric", "nonNegativeInteger", 
function(from)
{
   from = as.integer(from)  
   if(from < 0)
     stop("value must be non-neative")

   from
})

as.SOAPDateTime = as.SOAPDate =
function(x)
{
  if(inherits(x, "POSIXt"))
    return(x)

  x = as.character(x)
  
#  if(is.character(x))
       # check the format heuristically.
  x
}

token =
function(x)
{
  x = gsub(" +", " ", x)
  x = gsub("(\\\t|\\\r\\\n)", "", x)
    # trim the beginning and end
  x = gsub("(^ +| +$)", "", x, )  
  x
}  



# These correspond to the XMLSchema namespace (xsd in .SOAPDefaultNameSpaces)
#
SchemaPrimitiveConverters <-
                list("timeInstant" = as.POSIXct,
                     "int" = as.integer,
                     "float" = as.numeric,
                     "double" = as.numeric,
                     "string" = as.character,
                     "boolean" = SOAP.logical,
# Extensions from Datatypes schema                     
                     "decimal" = as.numeric)

  # Double up for the moment with xsd: prefixes to duplicate the existing entries.
SchemaPrimitiveConverters[paste("xsd", names(SchemaPrimitiveConverters), sep = ":")] <- 
                  SchemaPrimitiveConverters[names(SchemaPrimitiveConverters)]

zeroLengthArrays <-
                list("xsd:timeInstant" = as.POSIXct(character(0)),
                     "xsd:float" = numeric(0),
                     "xsd:int" = integer(0),
                     "xsd:float" = numeric(0),
                     "xsd:double" = numeric(0),                     
                     "xsd:string" = character(0),
                     "xsd:boolean" = logical(0),
# Extensions from Datatypes schema                     
                     "xsd:decimal" = numeric(0))



processSimpleList =
function(type, name)
{
  type = xmlGetAttr(type, "itemType")
  elType = SOAPType(type)
  new("RestrictedListType", name = name, elType = elType, elementType = type)
}




mapSOAPTypeToS =
  #
  # Take a SOAP type (by name or as a SOAPType object)
  # and find the name of the R data type that it maps to 
  # so that data type can be used in, e.g., a class representation
  # e.g. "int" goes to "integer".
  #
  #XXX Need to deal with namespaces. Tricky because they may have been
  # defined elsehwere, not in the top of the document. Need to match
  # the prefix to the actual URI and then compare URIs.
function(type, types = list(), namespaceDefs = list())
{

   if(is(type, "SimpleSequenceType")) {
       if(!is.na(type@name))
         return(type@name)
       
       tmp = mapSOAPTypeToS(type@elType, types, namespaceDefs)
       if(tmp %in%  c("character", "integer", "logical", "numeric"))
         return(tmp)
       else
         return("list") #XXX should constrain the element types.
   }
      
  
    if(is(type, "ClassDefinition")) {
       if(is.na(type@name)) {
         #XXX creat a representation
         return("numeric")
       } else
         return(type@name)
    }
  
    if(is(type, "AttributeDef")) 
       type = type@type

    if(is(type, "EnumValuesDef")) {
      if(length(type@name))
         return(type@name)
      # define a class based on the names and use that.
      # But we need a where.
    }
      
  
    if(is(type, "GenericSchemaType")&& !is.na(type@name) )
       type = type@name


    if(length(type) == 1) { # just one entry
      type =  strsplit(type, ":")[[1]]
      if(length(type) == 2)  # so we have a namespace as well as the type name
               # call this function again with these two elements.
        return(mapSOAPTypeToS(type, types, namespaceDefs))
    }

    if(length(type) == 2) {
      ns = type[1]
      type = type[2]
    }

    if(length(grep("^ArrayOf", type)) > 0 && type %in% unlist(c(sapply(types, names)))) {
        # just give back the name of the R type (to be)
      return(type)
      # return(mapSOAPTypeToS(gsub("^ArrayOf", "", type), types, namespaceDefs))
    }


    which = sapply(XMLSchemaTypes, function(x) x[["type"]] == type) #is this now correct?
    if(any(which))
      return((names(XMLSchemaTypes)[which])[1])

#    if(length(grep(":", type)))
#      type = gsub("^.*:", "", type)
    
    if(length(types)) {

      if(is(types, "SchemaCollection")) {
        for(i in types) {
           which = match(type, sapply(names(i), discardNamespace))
#XXXif(length(which) > 1) browser()
           if(!is.na(which))
               return(discardNamespace(names(i)[which]))
        }
      } else {

        which = match(type, names(types))
        if(!is.na(which))
            return(discardNamespace(names(types)[which]))        
      }
    }

  if(getOption("SSOAP_DEBUG", FALSE))  browser()
    
    warning("Can't match XML Schema type ", type)
    "XMLInternalNode"
}
