processSchemaTypes =
   # Process all the elements in types (hopefully <schema> elements)
   # and merge. We may want to keep these as a list indexed by namespace/schema identifier.
   # Is this still true?
  
   # Originally, we just processed the first one.
   # types = processSchemaTypes(doc[["types"]][[1]], doc)


  # We are called with the doc[["types"]] argument
  # That should contain a schema.  The schema
  # can have elements within it (e.g. interop.wsdl) or
  # import statements which give other schema, e.g. eutils.wsdl
  # or both import statements and new type defintions (e.g. KEGG.wsdl).
  #

  # This can be called recursively for sub-schema, i.e. schema defined within the
  # <types><schema>...</schema></types>

  # This is (initially) called with the top-level <types> which should contain one
  # <schema> node and potentially have <import> and <include> nodes within this.
  # We will process these recursively.

function(node, doc, namespaceDefs = xmlNamespaceDefinitions(doc), createConverters = FALSE, verbose = FALSE,
           types = NULL)
{
  if(is.null(node))
      return(list())

  substGroups = getSubstitutionGroups(doc)

  
     # Loop over the children of this node and process each element.
  ans = vector("list", xmlSize(node))
  names = character(length(ans))

 for(i in seq(length = xmlSize(node)))  {
                   el = node[[i]]

                   if(inherits(el, c("XMLCommentNode", "XMLInternalCommentNode"))
                         || xmlName(el) %in% c("import", "include"))
                     next

                   if(xmlName(el) == "annotation")
                     next
                   
                   if(xmlName(el) == "schema") {
                         # pubmed from NCBI has a <schema><schema targetNamespace="">...
                      if(xmlSize(el) == 1 && names(el) == "schema")
                        el = el[[1]]
                     
                      ns = xmlGetAttr(el, "targetNamespace")
                      if(verbose)
                         cat("processing (sub) schema", ns, "\n")

                      o = processSchemaTypes(el, doc, namespaceDefs, createConverters = FALSE, verbose = verbose, types = ans)
                      if(!is(o, "SchemaTypes"))
                          o = new("SchemaTypes", o)
                      o@elementFormQualified = xmlGetAttr(el, "elementFormQualified", FALSE, as.logical)
                      if(length(o)) {
                          ans[[i]] <-  o
                          if(length(ns) || length(ns <- xmlGetAttr(el, "namespace"))) {
                             names[i] <- ns
                             names(ans) <- names
                          }
                      }
                   } else {
                      n = xmlGetAttr(el, "name", as.character(NA))
                      if(verbose)
                         cat(i,")", n, " (", xmlName(el), ")\n")
                      
                      o = processSchemaType(el, substitutionGroups = substGroups,
                                            namespaceDefs = namespaceDefs,
                                            types = ans)
                      
                      if(is.null(o))
                         next
                      
                      if(FALSE && createConverters && is(o, "BasicSOAPType"))
                         o@fromConverter = createSOAPConverter(o, ans)

                      ans[[i]] <- o
                      names[i] <- o@name
                      names(ans) <- names
                    }

                   NULL
        }

         # Fix the names on these types to avoid the schema.
 #             types = unlist(types, recursive = FALSE)
 #names(types) = sapply(types, function(x) x$name)
 # types

      # if we have a collection of SOAPTypes, turn them into a SchemaTypes object
      # and if we have a collection of exclusively SchemaTypes  (i.e. separate Schema)
      # make a SchemaCollection. In between where we have separate types and
      # one or more schemas (containing types), we leave as is for now, i.e. just a list.
  if(!any(sapply(ans, inherits, "SchemaTypes")))
     ans = new("SchemaTypes", ans)
  else if(all(sapply(ans, inherits, "SchemaTypes"))) {
     ans = new("SchemaCollection", ans)
  }

  if(createConverters) 
     ans = addConverters(ans, ans)

  ans
}

setGeneric("addConverters",
           function(x, types, ...)
             standardGeneric("addConverters"))

setMethod("addConverters",
           "list",
           function(x, types, ...) {
             lapply(x, addConverters, x)
           })

setMethod("addConverters",
           "list",
           function(x, types = x, ...) {
             lapply(x, createSOAPConverter, types = types)
           })

setMethod("addConverters",
           "SchemaCollection",
           function(x, types = x, ...) {
             lapply(x, addConverters, types = types)
           })

sQuote =
function(x)
  sprintf("'%s'", x)


# This material relates to XML schema and processing of types defined within
# schema. Ideally, we will separate this into a separate package and use the
# results in different ways, not just for SOAP. And we will provide a more
# extensive framework for dealing with all of the schema details rather than
# the rather limited but common ones supported here.
#
#  See the O'Reilly book XML Schemas by Eric van der Vlist for more information
#  on schemas, or look on the Web (e.g. www.xml.com/schemas)
#
#  Priscilla Walmsley's Definitive XML Schema Prentice Hall
#  is much better. 

# Failed  complexType & attribute.
#   Assay_molTypeType
#   Assembly_currentType


processSchemaType =
  #
  # This is intended to create an R description for
  # XML Schema nodes that actually define a type.
  #
  #
  # This currently deals with a very small subset of XML schema
  # specifications.  These are the common ones, but more work 

  #

  #  simpleType
  #  complexType
  #  complexContent

   # sequence

  # Fix for
  #   simpleType with "attribute" child.
  #   simpleType with restriction.

  # Handle <group>
function(type, types, substitutionGroups = NULL, namespaceDefs = list())
{
   if(inherits(type, c("XMLInternalCommentNode", "XMLComment")))
      return(NULL)

  name = xmlGetAttr(type, "name", "")
#if(name %in% c("login")) browser()
   
#if(name %in% c("i", "iType", "b")) browser()

#if(name == "getAlleleCountResponse") {debug(processSchemaType); on.exit(undebug(processSchemaType))}

   if(xmlName(type) == "attribute")
     return(processAttribute(type, name))

   if(xmlName(type) == "attributeGroup" && !is.na(xmlGetAttr(type, "ref", NA)))
     return(getAttributeGroup(type))

  if(xmlName(type) == "sequence")
    return(processSequence(type, types, namespaceDefs, name))
   
  docString = character()

  if(xmlSize(type) > 0 && "annotation" == xmlName(type[[1]])) { 
         # drop the annotation sub-node.
    docString = xmlValue(type[[1]])
       # if dealing with internal nodes.
    removeNodes(type[[1]])
    # xmlChildren(type) = xmlChildren(type)[-1]    
  }

   
     #   simpleType only and return.

  if(xmlName(type) == "element" && !is.na(xmlGetAttr(type, "type", NA)) && xmlSize(type) == 0) {

    #XXXX  can we just call processSchemaElement and ignore the remainder of this if() body
    return(processSchemaElement(type, name, namespaceDefs, types))
    
       # an element that really just refers to another type definition.
    refName = discardNamespace( xmlGetAttr(type, "type") ) #XXX stripping away name space but have to be careful if there is more than one.
    refNode = getNodeSet(as(type, "XMLInternalDocument"), paste("//x:*[@name=", sQuote(refName), "]"),
                            c("x" = "http://www.w3.org/2001/XMLSchema"))

    w = sapply(refNode, function(x) xmlName(x) %in% c("element", "complexType") && xmlGetAttr(x, "name") == refName &&
                                  discardNamespace( xmlGetAttr(type, "type") ) == refName)
    refNode = refNode[!w]
    
    ref = if(length(refNode) == 0) {
             # lookup the ref in the basic types
             # NULL
           mapSOAPTypeToS(xmlGetAttr(type, "type"))
          } else {
             processSchemaType(refNode[[1]], types, namespaceDefs = namespaceDefs)
          }
    if(is.character(ref))
       ref = SOAPType(xmlGetAttr(type, "type"))
    return(new("Element", name = name, type = ref)) #XXX  attributes = ref@attributes,
    
  } else if(name == "simpleType" || xmlName(type) == "simpleType") {
    done = TRUE

    if(xmlSize(type) > 0 && xmlName(type[[1]]) == "restriction") {  # need to account for the annotation. Removed above.
#cat("simpleType -> restriction code\n");browser()         
       if(xmlSize(type[[1]]) > 0) {
            # check if the base type is a primitive (e.g. a double, ...)
            # and take care of the namespace, e.g. xs:double
         base = asQName(xmlGetAttr(type[[1]], "base"))
         if(!is.na(getRTypeFromSOAP(base[2], asIndex = TRUE))) { #XXX what if no prefix? Make asQName() return a vector of length 2?
#XXXX is this the right thing to do here at all?
           if(base[2] == "string") {
              def = createRestrictedStringDefinition(type, name)
           } else {
              tp = SOAPType(base[2], base[1], count = getElementCount(type))
              
              def = if(length(getNodeSet(type[[1]], "./*"))) {  # xmlSize(type[[1]])) {

                       if(base[2] == "integer") {
                         vals = xmlSApply(type[[1]],  xmlGetAttr, "value", converter = as.integer)
                         from = function(val) asIntegerSetValue(val, vals, name)
                         body(from)[[3]] = vals; body(from)[[4]] = name
                         new("RestrictedSetInteger", name = name, values = vals,
                                  toConverter = function(val) val,
                                  fromConverter = from)
                       } else
                         new("EnumValuesDef", name = name, values = xmlSApply(type[[1]],  xmlGetAttr, "value"))
                    } else
                       new("ExtendedClassDefinition", name = xmlGetAttr(type, "name", as.character(NA)), base = base[2])
           }
         } else
              # Assume enumeration values for present.
           def <- new("EnumValuesDef", name = name, values = xmlSApply(type[[1]],  xmlGetAttr, "value"))
           if(length(name) == 0)
                def@name = paste(def@values, collapse = ",")
       } else {
         # e.g. from eBaySvc.wsdl
         # <xs:simpleType name="DisputeIDType">
         #   <xs:restriction base="xs:string"/>
         # </xs:simpleType>
         def = new("ExtendedClassDefinition", name = name, base = xmlGetAttr(type[[1]], "base"))
       }
   } else if(xmlSize(type) > 0 && xmlName(type[[1]]) == "list") {
       if(xmlSize(type[[1]]) > 0) {
          el = processSchemaType(type[[1]][[1]], types, namespaceDefs = namespaceDefs)
          def = SOAPType(name, count = getElementCount(type), obj = new("RestrictedListType"))
          def@elType = el
          if(is(el, "EnumValuesDef"))  # And is a string
              def@elements = el@values
       } else if(xmlName(type) == "simpleType" && xmlName(type[[1]]) == "list"){
           def = processSimpleList(type[[1]],  xmlGetAttr(type, "name"))
       } else
           stop("Not sure what to do here with ", xmlName(type))
   } else if(xmlName(type[[1]]) == "union") {
      u = type[[1]]
      tp = xmlGetAttr(u, "memberTypes", "")
      types = lapply(xmlChildren(u), processSchemaType, types = types)
#if(name == "DocumentationEnumTypes") browser()
      def = new("UnionDefinition", name = name, slotTypes = c(types, strsplit(tp, "[[:space:]]+")[[1]]))
   } else
       def <- "xsd:string"

     if(done)
       return(def)
  }

   if("complexType" %in% names(type) && xmlSize(type[["complexType"]])  == 0) {
     return(new("Element", name = name, attributes = lapply(xmlChildren(type)[names(type) == "attribute"], processAttribute)))
   } else if(names(type)[1] == "complexType" && names(type[[1]]) == "simpleContent") {
      ext = type[[1]][[1]][[1]]
      kids = xmlChildren(ext)
      attrs = list()
      #!!! can use lapply now that we have general call to processSchemaTypes() rather than to different specific functions.
      for(i in kids[names(ext) %in% c("attribute", "attributeGroup")])
        attrs = c(attrs, processSchemaType(i, types, substitutionGroups, namespaceDefs = namespaceDefs))
      names(attrs) = sapply(attrs, slot, "name")

     return(new("SimpleElement", name = xmlGetAttr(type, "name", as.character(NA)),
                                 attributes = attrs,
                                 xmlAttrs = as(xmlAttrs(type), "character"),
                                 type = xmlGetAttr(ext, "base", character()) #XXX type should be the extension type
                  #               count = getElementCount(type)
                ))
  } else if(xmlName(type) %in% c("complexContent", "element")) {
         
      tmp = type
      
  } else if(xmlName(type) == "complexType" && xmlSize(type) == 0) {
          #??? What do we do here.  See "http://www.ebi.ac.uk/ebisearch/service.ebi?wsdl" for example.
    return(new("AnySOAPType", name = if(name != "") name else "AnySOAPType"))
  } else if(xmlName(type) == "complexType" && xmlName(type[[1]]) == "all")
    tmp = type
  else if(xmlName(type) == "complexType" && ( (xmlSize(type) == 1 && names(type) == "sequence")
                                              || ("sequence" %in% names(type)  && all(names(type) %in% c("attribute", "annotation", "sequence")))))  {
    return(processSequence(type[["sequence"]], types, namespaceDefs, name))
  } else if(xmlName(type) == 'complexType' && all(names(type) %in% c("attribute", "attributeGroup"))) {
      #XXX what about any attributes on the complexType such as mixed="true".
       # Just an attribute group within the complexType.

        # Make a separate function.
     attrs = list()
     for(i in xmlChildren(type))
        attrs = c(attrs, processSchemaType(i, types, namespaceDefs = namespaceDefs))
     names(attrs) = sapply(attrs, slot, "name")

     return(new("SOAPComplexType",
                 name = xmlGetAttr(type, "name"),
                 attributes = attrs,
                 xmlAttrs = as(xmlAttrs(type), "character")))
     
  } else if(xmlName(type) == "attribute") {
       # Case where xmlSize() > 0. But this must be (?)
       # a simpleType with a restriction on the type and so would be
       # handled in processAttribute(). So this could be simplified.
       # 
       # XXX is this right ? Think this must be handled by processAttribute() correctly.
       # We may have a restriction on the value. e.g. from the pmml schema
# <xs:attribute name="type" use="required">
#  <xs:simpleType>
#    <xs:restriction base="xs:string">
#      <xs:enumeration value="int"/>
#      <xs:enumeration value="real"/>
#      <xs:enumeration value="string"/>
#    </xs:restriction>
#  </xs:simpleType>
# </xs:attribute>
     return(processAttribute(type, name))
  } else 
    tmp <- type[["complexContent"]]

  if(xmlName(type) == "attributeGroup") {
        # We'll deal with these when they are referenced.
        # We could compute them just once and access that but where do we put them so that we can access them.
        # An environment like RGCCTranslationUnit.
      return(NULL)
      
  } else if(xmlName(type) == "element") {
       ans = processSchemaElement(tmp, namespaceDefs = namespaceDefs, types = types)
#if(name == "GetExtendedCompoundInfoResponse") browser()
       if(is(ans, "Element") && (length(ans@type@name) == 0 || is.na(ans@type@name) || ans@type@name == ""))
          ans@type@name = name
       return(ans)
  } else if(!is.null(tmp) && !is.null(tmp[["all"]])) {
        # Connect this with the other case !is.null(tmp <- type[["all"]]) below.
    
             # a struct-like definition with slots.
     a = tmp[["all"]]

     slotTypes = xmlApply(a, function(x) {
                                   # just return the SOAP type. We'll resolve it later.
                                  tt = xmlGetAttr(x, "type")
                                  if(length(tt) == 0) {
                                     tt = xmlGetAttr(x, "ref")
                                  }
                                  SOAPType(tt, nsuri = xmlNamespace(x), namespaceDefs = namespaceDefs, count = getElementCount(a))
                               })

     names(slotTypes) = xmlSApply(a, getElementName)
     def = ClassDef(name, slotTypes)

  } else if(!is.null(tmp) && !is.null(tmp[["extension"]])) {
     def = processExtension(tmp, name, types, namespaceDefs)
  } else if(!is.null(tmp) && !is.null(tmp[["restriction"]])) {
     def = processRestriction(tmp, name, types, namespaceDefs) 
  } else if(!is.null(tmp <- type[["all"]])) {
    
                    # a struct-like definition with slots.
     slotTypes = xmlApply(tmp, xmlGetAttr, "type")
     names(slotTypes) = xmlSApply(tmp, xmlGetAttr, "name")
     def = ClassDef(name, slotTypes, new("ArrayClassDefinition"))
     
  } else if(!is.null(tmp <- type[["sequence"]])) {
    
                    # <complexType><sequence>
                    # Connect this with the code for the "all" case.
                    # Need to resolve the type if it is not a primitive.
                    # XXX also want the minOccurs and maxOccurs

      def = SOAPType(name, counts = getElementCount(type), obj = new("SOAPComplexType"))
      def@xmlAttrs = as(xmlAttrs(type), "character")
      def@content = processSequence(tmp, types, namespaceDefs)
      def@attributes = lapply(xmlChildren(type)[names(type) == "attribute"], processAttribute)
      ags = xmlChildren(type)[names(type) == "attributeGroup"]
      doc = as(type, "XMLInternalDocument")
      for(i in ags) {
          attrs = getAttributeGroup(i, doc)
          def@attributes[names(attrs)] = attrs
      }

#XXX deal with attribute group.  
#    Also  xs:choice for an element with the <xs:all>

#      def = new("SimpleSequenceType", name = name, elType = slotTypes, elementType = slotTypes@name) 
#      def = ClassDef(name, slotTypes)
#      def@count = getElementCount(type)
      
  } else if (xmlName(type) == "choice") {
    def = processChoice(type, types, namespaceDefs)
  } else if(!is.null(tmp <- type[["choice"]])) {

      #XXX type or ref?
      # Handle local definitions
     # We can either get the names of the references to elemense
     # or get the actual types, assuming they have already been
     # processed.
    # "references-citedType" in ops.wsdl

     def = processChoice(tmp, types, namespaceDefs, name)

   } else if(!is.null(tmp <- type[["simpleContent"]])) {
      if(xmlName(tmp[[1]]) == "extension") {
        
                      # Assume the children are attributes for the moment.
         attrTypes = xmlApply(tmp[[1]], processSchemaType)
         names(attrTypes) = xmlSApply(tmp[[1]],  xmlGetAttr, "name")
                      #XXX Add base.
         base = xmlGetAttr(tmp[[1]], "base")         
         def <- ClassDef(name, attrTypes)

      } else
          def <- NULL
  } else if(xmlName(type) == "complexType" &&
               xmlSize(type) > 0 && all(xmlSApply(type, xmlName) == "attribute")) {

        els = xmlApply(type, processAttribute)
        name = xmlGetAttr(type, "name")
        def = new("SOAPComplexType", name = name, attributes = els)
        
        def@xmlAttrs = as(xmlAttrs(type), "character")

       # XXX
#<xs:complexType name="ArrayType" mixed="true">
# <xs:attribute name="n" type="INT-NUMBER" use="optional"/>
# <xs:attribute name="type" use="required">
#   <xs:simpleType>
#     <xs:restriction base="xs:string">
#       <xs:enumeration value="int"/>
#       <xs:enumeration value="real"/>
#       <xs:enumeration value="string"/>
#     </xs:restriction>
#   </xs:simpleType>
# </xs:attribute>
#</xs:complexType>

# <xs:complexType>
#  <xs:attribute name="name" type="xs:string" use="required"/>
#  <xs:attribute name="optype" type="OPTYPE"/>
#  <xs:attribute name="dataType" type="DATATYPE"/>
# </xs:complexType> 
  } else if(xmlName(type) == "complexType" &&  (xmlSize(type) == 0 || trim(xmlValue(type)) == "")) {
    def = ClassDef(name, list())
  } else {
     warning("Failed to handle node ", name, " of type ", xmlName(type),
              if(xmlSize(type) > 0) c(" & ", xmlName(type[[1]])), " in processSchemaType. ",
                as(type, "character"),
                 class = "ProcessWSDLTypeError")
     return(NULL)
  }

  if(is(def, "GenericSchemaType"))
    def@documentation = docString

  return(def)
 }

processChoice =
function(node, types, namespaceDefs, name = "")
{
#if(name %in% c("FieldSearchQuery", "LaunchPermissionOperationType")) browser()

         #??? Can we call processSchemaType instead of getType
#      slotTypes = xmlApply(node, getType, types, namespaceDefs)
      slotTypes = xmlApply(node, processSchemaType, types, namespaceDefs = namespaceDefs)
      names(slotTypes) = xmlSApply(node,  xmlGetAttr, "name")
        # Want to find the namespaces to identify the origin of the definition
        # in case of ambiguities and  also built-in types.
     # If getType resolves the SOAPType, then we 
     #      uris = getTypeNamespace(slotTypes, tmp)
     #      uris = sapply(slotTypes, function(x) x@nsuri)
#XXX
uris = as.character(rep(NA, length(slotTypes)))
      if(xmlSize(node) == 1)
        ClassDef(name, slotTypes[1], uris)
      else    
        UnionDef(name, slotTypes, uris)
}

getType =
function(node, types, namespaceDefs = list())
{
  if(xmlName(node) == "sequence") {
    processSequence(node, types, namespaceDefs)
  } else if(xmlName(node) == "choice") {
    processChoice(node, types, namespaceDefs, "")
  } else if(xmlName(node) == "element") {
    id = xmlGetAttr(node, "type", xmlGetAttr(node, "ref", as.character(NA)))
    lookupType(id, types, namespaceDefs, node = node)
  } else
    stop("Handle this case in getType for ", xmlName(node))
}

getElementName =
  #
  # Handles an <element name="..."> and <element ref="...">
  #
function(node)
{
   ans = xmlGetAttr(x, "name")
   if(length(ans))
     return(ans)

   ref = xmlGetAttr(x, "ref")
   if(length(ref)) {
      doc = as(node, "XMLInternalDocument")
      node = getNodeSet(doc, "//x:*[@name =", sQuote(ref), " or @name =", sQuote(discardNamespace(ref)), "]", "x")
      if(length(node))
        return(xmlName(node[[1]]))
   }

   NA
}

getElementName =
  #
  # And defined differently again!!!
  #
function(node)
  xmlGetAttr(node, "name", xmlGetAttr(node, "ref", as.character(NA)))


asCount =
function(x)
{
   if(x == "unbounded")
     Inf
   else
     as.numeric(x)
}

getElementCount =
function(node)
{
  c(min = xmlGetAttr(node, "minOccurs", 1L, as.integer),
    max = xmlGetAttr(node, "maxOccurs", 1L, asCount))
}


processSequence =
  #
  # There are two basic kinds of sequences:
  #   1) an ordered collection of 1 or more different elements, some optional
  #   2) zero or more instances of the same element
  #
  #  2) maps to a list in R, but we might need to impose a constraint on the number of entries in the list.
  #  1) maps to a class definition. It is a structure, perhaps with missing/NULL/default values for  elements.
  #
  # There are also choice groups
  #
  #
function(node, types, namespaceDefs = list(), name = getElementName(node))
{
  if(xmlSize(node) == 1 && !is.na(xmlGetAttr(node[[1]], "maxOccurs", NA))) {

     ans = new("SimpleSequenceType", name = name,
                                      elType = SOAPType(xmlGetAttr(node[[1]], "type", xmlGetAttr(node[[1]], "ref", as.character(NA))),
                                                         nsuri = xmlNamespace(node),
                                                         namespaceDefs = namespaceDefs,
                                                         counts = getElementCount(node[[1]]),
                                                        obj = new("SOAPTypeReference")))
     if(all(!is.na(ans@elType@count)) && all(ans@elType@count == 1)) {
          # if the sequence has a single element and the minOccurs and maxOccurs are both 1,
          # then return just the element.
        #XXX have to be careful that we recognize that the content is within the outer node given by name
       tmp = ans@elType
       return(tmp)
     }

     return(ans)
  
  }

#if(!is.na(name) && name == "references-citedType") browser()  

     # Build a SOAPType for each of the slots.
  slotTypes = xmlApply(node, function(x) {
                              typeName =  xmlGetAttr(x, "type", xmlGetAttr(x, "ref"))
                              SOAPType(typeName,
                                       nsuri = lookupNamespace(typeName, x),
                                       namespaceDefs = namespaceDefs,
                                       count = getElementCount(x))
                            })

  names(slotTypes) = ids = as.character(xmlSApply(node,
                                                   function(x)
                                                      xmlGetAttr(x, "name", xmlGetAttr(x, "ref", NA))))

  slotTypes = slotTypes[ ! sapply(slotTypes, is.null) ]
  
  if(TRUE || !is.na(name))
    ClassDef(name, slotTypes)
  else
    slotTypes
}


  

lookupNamespace =
function(id, node)
{
  els = strsplit(id, ":")[[1]]
  if(length(els) > 1)
     xmlSearchNs(node, els[1], asPrefix = TRUE)
  else
    getTargetNamespace(node)
}


# Children
# no children - simple element  esearch.xsd  Count.
# complexType with a sequence  egquery.xsd  Result
# simpletype

setClass("SchemaCollection", contains = "list")
setClass("SchemaTypes", representation(elementFormQualified = "logical"), contains = "list")

setClassUnion("SOAPTypeOrNULL", c("SOAPType", "NULL"))


     # xmlAttrs here are for the attributes on the XML node that we don't know how to process in place so hold on to.
     #  e.g. nillable = "true" on anyType in DailValues.asmx?wsdl
setClass("SchemaElement", representation(name = "character",  attributes = "list",
                                              xmlAttrs = "character"), contains = "GenericSchemaType") # was BasicSOAPType - added Sep 18 as an experiment.
                                                                                                       # GenericSchemaType added 28 Oct.
setClass("SimpleElement", representation(type = "character", nsuri = "character"), contains = "SchemaElement")

setClass("Element", representation(type = "SOAPTypeOrNULL"),
                     contains = "SchemaElement")


setClassUnion("AttributeType", c("EnumValuesDef", "character"))

setClass("AttributeDef", representation(name = "character",
                                        type = "AttributeType",
                                        use = "character",  # prohibited, optional, required
                                        default = "character",
                                        fixed = "character"
                                        ),
                         prototype = list(use = "optional"))


processSchemaElement =
function(element, name = xmlGetAttr(element, "name"), namespaceDefs = list(), types = NULL)
{

#if(!is.null(name) &&  name == "citation") browser()  
  attrs = xmlAttrs(element)
  if(all(c("name", "type") %in% names(attrs)))  {
        #XXX test this instead of the remainder of the if() body
      return(getElementRef(xmlGetAttr(element, "type"), element, types, namespaceDefs))

      #??? Why should this always be a SimpleElement.
      # e.g. <element name="foo" type="xsd:string"/>
      # should map to <foo>
    
      #XXX deal with nillable="true"
    els = strsplit(attrs["type"], ":")[[1]]
    if(length(els) > 1) {
      uri = findNamespaceDefnByPrefix(els[1], element)
      ty = els[2]
    } else {
     uri = getTargetNamespace(element)
     ty = els
   }
    
    return(new("SimpleElement", name = attrs["name"], type = ty, nsuri = uri))
  }

  if(!is.null(ref <- xmlGetAttr(element, "ref"))) {
      return(getElementRef(ref, element, types, namespaceDefs))
  }

  if(xmlSize(element) == 0) {
    obj =  new("SimpleElement", name = name)
  } else if(names(element)[1] == "complexType" && all(names(element[[1]]) == "attribute")) {
     # e.g. ParameterField, ArrayType in PMML.
    obj = new("SimpleElement", name = xmlGetAttr(element, "name", as.character(NA)),
                                attributes = xmlApply(element[[1]], processAttribute),
                                type = character() #,   count = getElementCount(element)
                )
    
  } else {
      # complexType
    if(xmlName(element[[1]]) == "complexType") {
        type = processSchemaType(element[[1]], types, namespaceDefs = namespaceDefs)
        obj = new("Element", name = name, type = type)

        i = xmlSApply(element[[1]], xmlName) == "attribute"
        if(any(i))  {
          obj@attributes = sapply(xmlChildren(element[[1]])[i], processAttribute)
          names(obj@attributes) = sapply(obj@attributes, slot, "name")
        }

        # obj@elements = xmlApply(element[[1]], processSchemaType, types, namespaceDefs = namespaceDefs)
        
      } else
         obj = NULL  
  } 

  obj
}


getElementRef =
function(id, node, types = NULL, namespaceDefs = list())
{
   els = strsplit(id, ":")[[1]]
   uri = findNamespaceDefnByPrefix(els[1], node)
#XXX should be an element reference.   
   new("SOAPTypeReference", name = els[2], nsuri = uri, ns = els[1])
}

getAttributeGroup = 
function(refNode, doc = as(refNode, "XMLInternalDocument"))
{
        #XXX We take off any names space. We should be more careful here if there is more than one namespace.
     groupName = discardNamespace( xmlGetAttr(refNode, "ref") )
     agroup = getNodeSet(doc, paste("//xs:attributeGroup[@name=", sQuote(groupName), "]"), c(xs="http://www.w3.org/2001/XMLSchema"))
     if(length(agroup) == 0)
       stop("Cannot find attribute group named ", sQuote(groupName))
     processAttributeGroup(agroup[[1]])
}

processAttributeGroup =
function(node)
{
  tmp = sapply(xmlChildren(node)[names(node) == "attribute"], processAttribute)
  names(tmp) = sapply(tmp, slot, "name")
  tmp
}

processAttribute =
function(node, name = xmlGetAttr(node, "name"), type = xmlGetAttr(node, "type", as.character(NA)))
{
   if(!is.null(ref <- xmlGetAttr(node, "ref"))) {
      tmp = getNodeSet(as(node, "XMLInternalDocument"), sprintf("//xsd:schema/xsd:attribute[@name='%s']",
                                                                gsub("[a-z0-9]+:", "", ref)),
                  c(xsd = "http://www.w3.org/2001/XMLSchema"))
      if(length(tmp) == 0)
         stop("Cannot find attribute reference for ", ref)
      node = tmp[[1]]
   }
     
   if(is.na(type) && xmlSize(node)) {
     if(xmlName(node[[1]]) == "simpleType" &&
           xmlName(node[[1]][[1]]) == "restriction") {
        # handle non-string types too in the restriction.
#XXX Was       
       type = new("EnumValuesDef", values = xmlSApply(node[[1]][[1]], xmlGetAttr, "value"))
       type@name = paste(type@values, collapse = ",")
# Should be        
#       type = processSchemaType(node[[1]], types, namespaceDefs = namespaceDefs)
     } else
        warning("<fixme> Skipping children in <attribute> definition")
    }

   
   new("AttributeDef", name = name,
                       type = type,
                       use = xmlGetAttr(node, "use", "optional"),
                       default = xmlGetAttr(node, "default", as.character(NA)),       
                       fixed = xmlGetAttr(node, "fixed", as.character(NA)))
}



getSubstitutionGroups =
  #
  # doc = xmlParse("../inst/samples/kml21.xsd")
  # g = getSubstitutionGroups(doc)
  # by(g, g$group, function(x) x)
  #
  # Need to include this information in the class definitions.
  #
  #  e.g. kml:Geometry is a kml:Geometry and there are
  # the following in the substitutionGroup
  #         name                  type        group  
  #MultiGeometry kml:MultiGeometryType kml:Geometry
  #        Point         kml:PointType kml:Geometry
  #   LineString    kml:LineStringType kml:Geometry
  #   LinearRing    kml:LinearRingType kml:Geometry
  #      Polygon       kml:PolygonType kml:Geometry
  #        Model         kml:ModelType kml:Geometry  
  #
  # XXX Check for nesting in groups
  # 
  #
function(doc)
{
   groups = getNodeSet(doc, "//*[@substitutionGroup]")
   type = sapply(groups, xmlGetAttr, "type", as.character(NA))
   data.frame(name = sapply(groups, xmlGetAttr, "name"),
              type = type,
              group = sapply(groups, xmlGetAttr, "substitutionGroup"))
}

createRestrictedStringDefinition =
function(type, name)
{
           #This is wrong!
           # new("EnumValuesDef", name = name, values = xmlSApply(type[[1]],  xmlGetAttr, "value"))
  kids = xmlChildren(type[[1]])[ ! xmlSApply(type[[1]], is, "XMLInternalTextNode") ]

  names = sapply(kids, xmlName)

  if(all(names == "enumeration")) {
    vals = if(length(kids))
              sapply(kids,  xmlGetAttr, "value")
            else
              character()
     new("RestrictedStringDefinition", name = name, values = vals,
                  ns = "xsd", nsuri = c(xsd = "http://www.w3.org/2001/XMLSchema"))
  } else {

    if(any(names == "pattern")) {
       pattern = xmlGetAttr((kids[names(kids) == "pattern"])[[1]], "value")
       def = new("RestrictedStringPatternDefinition", name = name, pattern = pattern,
                     ns = "xsd", nsuri = c(xsd = "http://www.w3.org/2001/XMLSchema"))
       def@fromConverter = function(from) as(from, "character")
       epattern = paste("^", pattern, "$", sep = "")
       def@toConverter = function(from) {
                             x = as(from, "character")
                             if(length(grep(epattern, x)) == 0)
                               stop("Invalid string: doesn't match expected pattern")
                             x
                         }
       def
    }
  }
}


processExtension =
function(type, name, types, namespaceDefs)
{
     base = xmlGetAttr(type[["extension"]], "base")
                      # Now get the extensions.
#??? do we need to fix the namespace prefix, e.g. kml:ObjectType

     baseType = lookupType(base, types, namespaceDefs, node = type)

       # start with no slot types.
     def = ClassDef(name, list(), obj = new("ExtendedClassDefinition"))
     def@base = base
     type = type[[1]]
 #XXX can have a sequence and other elements/attributes
 # Also the sequence may not return a list for slotTypes     
     if(xmlSize(type) > 0 && xmlName(type[[1]]) == "sequence") {
               # ??? Should  we put this in a list as we now do?
               # removed the list for now. (Sun 18 Oct '09). For cuahsi.

       tt = processSequence(type[[1]], types, namespaceDefs)  #XXX what about the name argument
       if(!is.list(tt))
          tt = list(tt)
       def@slotTypes = tt
     }

    def
}

lookupType =
  # getType is to avoid getting an Element
function(name, types, namespaceDefs = list(), getType = TRUE, node = NULL)
{
 #XXX Deal with distinguishing between elements/references and actual types.
  # getType is intended to control whether this happens or not.
  
     id = strsplit(name, ":")[[1]]
     if(length(id) == 2) {
        i = match(id[1], names(namespaceDefs))
        if(is.na(i)) {
          if(length(node))  {
              #???
             u = getTargetNamespace(node)
             if(length(u) == 0)
                stop("Need to determine URI")
          } else
          stop("Need to determine URI")
        } else
          u = namespaceDefs[[i]]$uri
        
        if(u %in% names(types))
           igetSchemaType(id[2], types[[u]])
        else if(!is.null(node) && id[2] %in% names(types) && length(xmlSearchNs(node, u, asPrefix = FALSE))) {
            # See if this is in the current target namespace
              igetSchemaType(id[2], types)
        } else {
           uri = xmlSearchNs(node, u, asPrefix = FALSE)
           new("SOAPTypeReference", nsuri = uri, ns = id[1], name = name)
        }
     } else {
        igetSchemaType(id, types)
     }
}

igetSchemaType =
  # internal function.
function(name, schema, getType = TRUE)  
{
  if(is(schema, "SchemaCollection") && length(schema) == 1)
    schema = schema[[1]]
  
  i = match(name, names(schema))
  if(all(is.na(i)))
    return(NULL)

  if(sum(!is.na(i)) == 1)
     return(schema[[ !is.na(i) ]])

  types = schema[!is.na(i)]
  w = ! sapply(types, inherits, c("Element", "SOAPTypeReference"))
if(!any(w))
  warning("Ooops")
  types[[w]]
}

processRestriction =
function(type, name, types, namespaceDefs)
{  
                   # Currently we interpret this as an Array.
                   # So get the <restriction><attribute> element
                   # and take the arrayType and ref attribution from that.
            # In interop.wsdl, we also have a <sequence> <element> ... node within this restriction.
#cat("dealing with restriction\n");browser()    
    restriction = type[["restriction"]]
    a = restriction[["attribute"]]
    if(is.null(a)) {
          # See pmml-3-2.xsd and the "row" element.
          #XXXXXXXX
        base =  xmlGetAttr(restriction, "base")
        if(xmlSize(restriction) > 0) {
          def =  processSchemaType(restriction, types, , namespaceDefs = namespaceDefs)
          def@name = name
        } else {
           warning("case not handled")
           def = NULL
        }
        
    } else {
       def = ArrayType(xmlGetAttr(a, "arrayType", addNamespace = FALSE), ns = xmlNamespace(a), namespaceDefs = namespaceDefs)
       def@name = name
    }

    def
}

getTypeNamespace =
function(typeNames, node)
{
  if(length(typeNames) == 0)
     return(as.character(NA))
  
  els = strsplit(unlist(typeNames), ":")
  prefixes = sapply(els, function(x) if(length(x) > 1) x[1] else NA)

  if(all(i <- is.na(prefixes)))
    return(prefixes)

  uris = as.character(rep(NA, length(prefixes)))

  uris[!i] = sapply(prefixes[!i], findNamespaceDefnByPrefix, node)

  names(uris) = prefixes
  uris
}

findNamespaceDefnByPrefix =
function(prefix, node)
{
    #XXX Currently have to assume the namespace is on the schema element
  sc = getNodeSet(node, sprintf("./ancestor::xs:schema[namespace::%s]", prefix),
                    namespaces = c(xs="http://www.w3.org/2001/XMLSchema"))
  if(length(sc) == 0)
    return(as.character(NA))

    # Using the last node found.  Not guaranteed.
  defs = xmlNamespaceDefinitions(sc[[length(sc)]], simplify = TRUE)
  defs[prefix]
}




getTargetNamespace =
  #
  # For a given XML node given by type, find the 
  # target namespace from the associated <schema>
  # as both the URI and the prefix.
function(type)
{
   ns = getNodeSet(type, ".//ancestor::xs:schema",  c(xs="http://www.w3.org/2001/XMLSchema"))
   if(length(ns) == 0)
       return(as.character(NA))
   
   tns = xmlGetAttr(ns[[length(ns)]], 'targetNamespace')

   ns = xmlSearchNs(type, tns, asPrefix = FALSE)
   if(length(ns))
     names(tns) = names(ns)

   tns
}
