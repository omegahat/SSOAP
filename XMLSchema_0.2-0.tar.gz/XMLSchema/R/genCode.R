verbose = FALSE

capitalizeFirstLetter =
function(word)
{
  els = strsplit(word, "")[[1]]
  els[1] = toupper(els[1])
  paste(els, collapse="")
}

convertToSName =
  #
  #  Convert a string to a "legitimate" name in the S/R language.
  #
function(name, useDash = if("UseDashInSOAPNames" %in% names(options()))
                            getOption("UseDashInSOAPNames")
                         else
                            TRUE)
{
  if(useDash)
    return(name)
  
  els = strsplit(name, "_")[[1]]
  if(length(els) == 1)
    return(els)
  
  els[2:length(els)] = sapply(els[-1], capitalizeFirstLetter)

  paste(els, collapse="")
}


defineClasses =
  #
  # namespaceDefs is used in mapSOAPTypeToS as the third argument.
  #
function(types,  where = globalenv(), namespaceDefs = list(), verbose = FALSE,
          baseClass = "VirtualSOAPClass", force = FALSE)
{
  if(is(types, "SchemaTypes"))
    types = structure(list(types), class = "SchemaCollection")
  
  pending = new.env(hash = TRUE, emptyenv())
  classes = new.env(hash = TRUE, emptyenv())  
       # for each schema, define each type.
  lapply(types,  function(schema)  lapply(schema, defClass, where, namespaceDefs, verbose, pending, classes, types, baseClass, force))
}

showDefClassTrace = FALSE


setGeneric("defClass",
function(i, where = globalenv(),
         namespaceDefs = list(),
         verbose = FALSE,
         pending = NULL, # new.env(hash = TRUE, emptyenv()),
         classes = new.env(hash = TRUE, emptyenv()),
         types = NULL,
         baseClass = "VirtualSOAPClass", force = FALSE,
         name = if(is(i, "GenericSchemaType")) i@name else i$name,
         ignorePending = FALSE)
{
    if(is.null(i))
      return(FALSE)

    if(is(i, "SchemaTypes"))
     return(standardGeneric("defClass"))
    
    type = i
    if(verbose) {
      cat("<defClass>", name, "\n")
      on.exit(cat("finished", name, "\n"))
    }

           # if it is already defined, skip this unless force is TRUE.
   if(!force && !is.null(getClassDef( name, where )))
      return(structure(FALSE, names = "class already exists"))

           # if it is currently pending, then don't do it as we will get recursive calls.
   if(!ignorePending && exists(name, pending))
      return(structure(NA, names = "pending definition"))

           # register the type as pending since we are about to define it.
     assign(name, "TRUE", pending)
     on.exit({   # arrange to clean this up.  ??? Should we do this if overridePending = TRUE
               if(verbose && exists(name, envir = pending, inherits = FALSE)) {
                 cat("Removing ", name, "from pending\n")
                 remove(list = name, envir = pending, inherits = FALSE)
              }
             })    
    
  
    def = standardGeneric("defClass")
    
    if(!is.null(def)) {

      if(is(type, "BasicSOAPType") && length(body(type@fromConverter)) > 1) {
        if(verbose)
            cat("defining setAs() for", type@name, "\n")
        if(is(type@fromConverter, "SOAPElementConverter"))
           cvt = as(type@fromConverter, "AsFunction")
        else
           cvt = type@fromConverter
        setAs("XMLAbstractNode", type@name, cvt, where = where)
      }         
      
      assign(name, def, classes)

      def
    } else
      NULL    
})

setMethod("defClass", "SchemaTypes",
          function(i, where = globalenv(),
                   namespaceDefs = list(),
                   verbose = FALSE,
                   pending = NULL, # new.env(hash = TRUE, emptyenv()),
                   classes = new.env(hash = TRUE, emptyenv()),
                   types = NULL,
                   baseClass = "VirtualSOAPClass", force = FALSE,
                   name = if(is(i, "GenericSchemaType")) i@name else i$name,
                   ignorePending = FALSE) {

    lapply(i, defClass, where, namespaceDefs, verbose, pending, classes, types, baseClass, force)
   })


setMethod("defClass", "ANY",
          function(i, where = globalenv(),
                   namespaceDefs = list(),
                   verbose = FALSE,
                   pending = NULL, # new.env(hash = TRUE, emptyenv()),
                   classes = new.env(hash = TRUE, emptyenv()),
                   types = NULL,
                   baseClass = "VirtualSOAPClass", force = FALSE,
                   name = if(is(i, "GenericSchemaType")) i@name else i$name,
                   ignorePending = FALSE) {
  def = NULL

if(name == "ResourceIdSetType") {
  unlockBinding("showDefClassTrace", getNamespace("XMLSchema"))
  showDefClassTrace <<- TRUE
}

if(showDefClassTrace)
  print(sys.calls())  
   
         if(is(i, "XMLAbstractNode") || is.null(i)) {
           return(NA)
         }

         type = i

# if(name == "ResourceIdSetType")  browser()
  
         if(is(i, "AnySOAPType")) {
             if(verbose)
                 cat("defining", name, "\n")
             setClass(name, where = where)
     	     return(TRUE)
	 }
          

         o = i
         if(!is(i, "GenericSchemaType"))
           i = i$definition

         if(is(i, "RestrictedStringDefinition")) {

            valid = function(object) {
               values = ""
               if(!any(object == values))
                  stop(object, " is not a recognized value ", paste(sQuote(values), collapse = ', '))
               TRUE
            }
            body(valid)[[2]][[3]] = i@values
            def = setClass(name, contains = "character", validity = valid, where = where)
            

         } else if(is(i, "RestrictedSetInteger")) {

            # add a validity
           def = setClass(name, "integer", where = where)
             # coercion method.
           fun = function(from) asIntegerSetValue(from, 'a', 'b')
           body(fun)[[3]] = i@values
           body(fun)[[4]] = name
           setAs("numeric", name, fun, where = where)

         } else if(is(i, "EnumValuesDef")) {

           elName = paste(name, "Values", sep = "_")
           assign(elName, as.character(i@values), envir = where)
           #XXX No ZZ and no validateEnum!
#           f = function(object) validateEnum(object, ZZ)
# See RGCCTranslationUnit and RAutoGenRunTime....           
#           body(f)[[3]] = as.character(i@values)
           f = NULL

            if(verbose)
                cat("defining class", name, "\n")           

           def = setClass(name, contains = c("character", baseClass), validity = f, where = where)
           
         } else if(is(i, "ClassDefinition")) {

               #   def <- createTypeClass(i, types, where = where)                       

           def = defineClassDefinition(i, types, namespaceDefs, name, classes, pending, baseClass, where, verbose, force)
           
         } else if(is(i, "Element")) {
               # recursively define the type, using the Element's name.
if(verbose) cat("<defClass>element", type@name, "\n")
           def = defClass(i@type, where, namespaceDefs, verbose, pending, classes, types, baseClass, force, name = type@name, ignorePending = TRUE)
           return(def)
         } else if(is(i, "SimpleSequenceType")) {   # XXX was "ArrayType" Nov 6.
            def = createArrayClass(i, types, where = where, verbose = verbose)
         } else if(is(i, "SOAPComplexType")) {
             # attributes and content
             #XXX We should convert the SOAPComplexType to a class definition before we get to this stage.
             #  i.e. in processWSDL()
           if(verbose)
              cat("defining", i@name, " (temporary solution)\n")
           setClass(i@name, where = where)
           return()
         }  else if(is(i, "UnionDefinition")) {
            defUnionClass(i, types, nsURI = i@uris, name = name, where, verbose = verbose, force = force)
         } else if(is(i, "SimpleElement")) {

         } else {
           warning("defClass: no code to handle ", class(i), " for ", i@name)
           def = NULL
         }
    })


setMethod("defClass", "NULL",
          function(i, where = globalenv(),
                   namespaceDefs = list(),
                   verbose = FALSE,
                   pending = NULL, # new.env(hash = TRUE, emptyenv()),
                   classes = new.env(hash = TRUE, emptyenv()),
                   types = NULL,
                   baseClass = "VirtualSOAPClass", force = FALSE,
                   name = if(is(i, "GenericSchemaType")) i@name else i$name,
                   ignorePending = FALSE) {

                 return(FALSE)
               })



setMethod("defClass", "SOAPTypeReference",
          function(i, where = globalenv(),
                   namespaceDefs = list(),
                   verbose = FALSE,
                   pending = NULL, # new.env(hash = TRUE, emptyenv()),
                   classes = new.env(hash = TRUE, emptyenv()),
                   types = NULL,
                   baseClass = "VirtualSOAPClass", force = FALSE,
                   name = if(is(i, "GenericSchemaType")) i@name else i$name,
                   ignorePending = FALSE) {
     def = getClassDef(i@name)
     if(length(def) == 0) {
         # then resolve and define
       def = lookupType(i@name, types)
       if(!is.null(def))
          def = defClass(def, where, namespaceDefs, verbose, pending, classes, types, baseClass, force)
       # stop("Need to define the reference ", i@name)
     }
     def
    })


setMethod("defClass", "RestrictedStringPatternDefinition",
#XXX See also createRestrictedStringDefinition in processSchemaTypes.R
          function(i, where = globalenv(),
                   namespaceDefs = list(),
                   verbose = FALSE,
                   pending = NULL, # new.env(hash = TRUE, emptyenv()),
                   classes = new.env(hash = TRUE, emptyenv()),
                   types = NULL,
                   baseClass = "VirtualSOAPClass", force = FALSE,
                   name = if(is(i, "GenericSchemaType")) i@name else i$name,
                   ignorePending = FALSE) {

        #Set the validity to enforce the pattern is met.
        #??? Can we use i@fromConverter
        valid = makeRestrictedPatternStringValidity(i@pattern, i@name)
        def = setClass(name, contains = "character", where = where, validity = valid)
       
        def
     })

makeRestrictedPatternStringValidity =
function(pattern, name)
{
  function(object) {
     if(grepl(pattern, object))
        TRUE
     else
       paste("%s doesn't match pattern %s for class %s", object, pattern, name)
  }
}

setClass("SOAPElementConverter", contains = "function")
setClass("AsFunction", contains = "function")

setAs("SOAPElementConverter", "AsFunction",
       function(from) {
         params = formals(from)
         formals(from) = alist(from =)
         b = expression({ x = from; obj = new("GetSitesXml")})
         ob = body(from)[-1]
         b[[1]][1:length(ob) + 4] =  ob
         body(from) = b
         from
       })
       


defineClassDefinition =
function(i, types, namespaceDefs, name, classes, pending, baseClass, where = globalenv(), verbose = FALSE, force = FALSE)
{
                 # make certain the types for the fields are defined
            repn = createClassRepresentation(i, types, namespaceDefs)
            m = sapply(repn, function(x)  is.null(getClassDef(x)) )
            if(any(m)) {
               if(verbose) 
                cat("Digressing to define", paste(repn[m], collapse = ", "), "for", name, "\n")

                # Now we recursively call this function to define these outstanding nodes.
                # We do have to worry about the depth of the call stack as this could grow
                # quite large if the classes are given in the wrong order.
                #XXX  only looking in first schema here.
              sapply(repn[m], function(x) {
                                   # look in all of the types 
                                 for(i in seq(along = types)) {
                                    type = types[[i]][[x]]
                                    if(!is.null(type))
	                                 break
                                 }

                                 if(!is.null(type)) 
                                    defClass(type, where, namespaceDefs, classes = classes, pending = pending, baseClass = baseClass, 
                                              types = types, verbose = verbose, force = force)

                              })
            }

            if(is(i, "ExtendedClassDefinition")) {
#cat("ExtendedClassDefinition", i@name, "\n") ; browser()

                xbaseClass = mapSOAPTypeToS(i@base, types = types)
                if(is.null(getClassDef(xbaseClass))) {
                   w = sapply(types, function(x) xbaseClass %in% names(x))
                   if(any(w))
                       defClass(types[[which(w)[1]]][[xbaseClass]], where, namespaceDefs, verbose, pending = pending,
                                 classes, types, baseClass, force)
                }

		super = names(getClass(xbaseClass)@contains)
                if(!(baseClass %in% super))
                   baseClass = c(xbaseClass, baseClass)
                else
                   baseClass = xbaseClass

            }

            if(verbose)
                cat("defining class", name, "\n")

            
           setClass(name, representation = repn, where = where, contains = baseClass)
}





W3SchemaURIs =
list( "1.1" =
        c('xsi'="http://www.w3.org/1999/XMLSchema-instance",
          'xsd'="http://www.w3.org/1999/XMLSchema"),
      "1.2" =
       c( 'xsi'="http://www.w3.org/2001/XMLSchema-instance",
          'xsd'="http://www.w3.org/2001/XMLSchema"))

getXSDSchemaURIs =
function(version = "1.2", all = FALSE) {
  if(all)
    unlist(W3SchemaURIs)
  else
    W3SchemaURIs[[version]]
}  


coerceArgumentCode =
function(id, type)
{
  if(is.null(type))
    return(id)
  
  name = convertToSName(id)
  default = paste("as(", id, ", '", type@name, "')", sep = "")
  
  if(length(type@nsuri) && type@nsuri %in% getXSDSchemaURIs(all = TRUE)) {
     which = match(type@name, sapply(XMLSchemaTypes, "[[", "type"))
     ifelse(!is.na(which) && type@name != "anyType",
             paste("as.",  names(XMLSchemaTypes)[which], "(", id, ")", sep = ""),
             default)
  } else if(is(type, "ArrayType")) {

     if(is(type@elType, "PrimitiveSOAPType")) {
        coerceArgumentCode(id, type@elType)
     } else {
          # Or we could go straight to R nodes
                                           #\/ Make sure this is the the name of the R class!
       paste("lapply(", name, ", as, ", type@elType@name, ")") 
     }
    
  } else {
    default
  }
}


setGeneric("getRClassName",
           function(id, ns, types)
            standardGeneric("getRClassName"))

setMethod("getRClassName", "SOAPType",
  # See mapSOAPTypeToS
function(id, ns, types)
{
    id@name
})

setMethod("getRClassName", "character",
  # See mapSOAPTypeToS
function(id, ns, types)
{
  #XXX Deal with the builtin types in XSD
  if(!is.na(ns) && ns %in% getXSDSchemaURIs(all = TRUE)) {
    mapSOAPTypeToS(id)
  } else {
     q = asQName(id)
     q[length(q)]
  }
})
  

defUnionClass =
function(type, types = NULL, nsURI = rep(NA, length(type)),
          name = type@name, where = globalenv(), verbose = FALSE, force = FALSE)
{
      # Loop over the types and get the names of the corresponding R classes
#   elTypes = mapply(getRClassName, unlist(type@slotTypes), nsURI, types)
  slotTypes = lapply(type@slotTypes, resolve, types)
# It would be convenient to have an additional argument passed through to 
# all the   functions as we define classes that map the name to the
# R name and then we could just look that up.
# Some types will be anonymous and so not be in the already defined.  
   elTypes = mapply(getRClassName, slotTypes)
   setClassUnion(name, elTypes, where = where)
   name
}

simple.dQuote =
function(x)
  paste('"', x, '"', sep = "")



if(FALSE) {

  createTypeClass =
  # probably not called anymore as lifted into the defineClasses() function above.
    function(type, types, where = globalenv(), parentClass = "VirtualSOAPClass",
         namespaceDefs = list())
      {
        if(verbose)
          cat("[createTypeClass]", type$name, "\n")
        repn = createClassRepresentation(type$definition, types, namespaceDefs)
        setClass(type$name, representation = repn, where = where, contains = parentClass)
      }
}


createArrayClass =
  # Should be merged into createTypeClass.sl
  #XX parentClass not used
function(type, types, where = globalenv(), parentClass = "VirtualSOAPClass", verbose = FALSE)
{

#  name = type$definition@elementType
  if(is(type, "GenericSchemaType")) {
    el = type@elType
    name = type@name
  } else {
    el = type$definition@elType
    name = type$name    
  }


  elName = if(is(el, "GenericSchemaType")) el@name else el$name

  builtinClass = "list"
  which = NA
  
    # Want to see if this is a basic type in R, e.g. integer
  if(el@nsuri %in% getXSDSchemaURIs(all = TRUE)) {
    # builtinClass = getArrayElementTypeFromName(name)
    which = match(elName, sapply(XMLSchemaTypes, "[[", "type"))
    if(!is.na(which))
      builtinClass = names(XMLSchemaTypes)[which]
     #    if(is.na(builtinClass))
     # stop("can't identify array element type for SOAP definition")
  }

  if(verbose)
    cat("defining class", name, "\n")
  
        #XXX want a typed list where the elements are checked. See DCOM code.
  ans = setClass(name, contains = builtinClass, where = where)

  fun = function(from)
             xmlSApply(from, as, "x")
  body(fun)[[4]] = if(!is.na(which)) builtinClass else elName
  setAs("XMLInternalElementNode", name, fun, where = where)

  ans
}

getRTypeFromSOAP =
function(el, col = "xsi:type", asIndex = FALSE)
{
 target = if(col == "xsi:type") paste("xsd:", el, sep = "") else el
 i = match(target, sapply(XMLSchemaTypes, function(x) x[[col]]))
 if(asIndex)
   return(i)
 
 if(!is.na(i))
   el = names(XMLSchemaTypes)[i]
 
 el
}

getArrayElementTypeFromName =
function(name, stripArray = TRUE, convertToRType = TRUE)
{
 els = strsplit(name, ":")[[1]]
 if(length(els) > 1) {
   els = els[2]
 }
 if(stripArray)
   els = gsub("\\[\\]$", "", els)

 if(!convertToRType)
   return(els)

 getRTypeFromSOAP(els)
}  


newSOAPClass =
  #
  # Creates a new instance of the specified class (className) and populates its
  # fields with the values from the XML node.
  #
  #XXX converters is not used here yet.
function(node, className, converters = SchemaPrimitiveConverters, type = NULL)
{
 obj = new(className)
 
 for(i in slotNames(className)) {
   tmp = node[[i]]
   if(!is.null(type))
     slotType = type@slotTypes[[i]]
   else
     slotType = NULL

   slot(obj, i) <- fromXML(tmp, type = slotType) #XXX Need SOAP type here!
 }

 
  obj
}


createClassRepresentation =
 #
 # 
function(type, types, namespaceDefs = list())
{
   repn = lapply(type@slotTypes, mapSOAPTypeToS, types, namespaceDefs)
   nas = sapply(repn, is.na)
   if(any(nas))
     stop("problem resolving SOAP type ", names(type)[nas], class = "ResolveSOAPType")

   repn
}




if(FALSE) {

# f = function(){}
# formals(f) <- alist(server=, kid=, threshold=, orgs=)
  
 body(f) <- substitute({
  val = .SOAP(server,
              .opName,
              action = .action,
              xmlns = .namespace,
              .types = ..types)
  }, 
  list(.opName= operation@name,
       .action = operation@action,
       .namespace = operation@namespace,
       ..types = operation@parameters))

  # now put the arguments in.
 e = body(f)[[2]]
 kk = e[4:length(e)]
# for(i in )
 k = body(f)[[2]][[3]]
}

# body(f) = substitute(body(f), list(.opname=operation@name))




asIntegerSetValue =
function(val, values, className)
{
   val = as.integer(val)  
   if(is.na(match(val, values)))
     stop("invalid integer value for class ", className)

   val
}
